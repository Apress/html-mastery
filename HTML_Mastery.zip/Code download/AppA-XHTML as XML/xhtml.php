<?php
if (strpos($_SERVER['HTTP_ACCEPT'],'application/xhtml+xml')) 
	{
		header('Content-type: application/xhtml+xml; charset=UTF-8');
	} else {
		header('Content-type: text/html; charset=UTF-8');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>XHTML</title>
</head>

<body><div><ruby>
  <rb>WWW</rb>
  <rp>(</rp><rt>World Wide Web</rt><rp>)</rp>
</ruby></div>
<div>
<ruby>
  <rbc>
    <rb>10</rb>
    <rb>31</rb>
    <rb>2002</rb>
  </rbc>
  <rtc>
    <rp>(</rp><rt>Month</rt><rp>)</rp>
    <rt>Day</rt>
    <rt>Year</rt>
  </rtc>
  <rtc>
    <rt rbspan="3">Expiration Date</rt>
  </rtc>
</ruby>
</div>
</body>
</html>
